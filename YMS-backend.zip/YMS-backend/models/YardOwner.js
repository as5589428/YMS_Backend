const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const YardOwnerSchema = new Schema({
  yardname: {
    type: String,
    required: true,
    unique: true,
  },
  contact_person: {
    type: String,
    required: true,
  },
  state: {
    type: String,
    required: true,
  },
  district: {
    type: String,
    required: true,
  },
  city: {
    type: String,
    required: true,
  },
  pincode: {
    type: String,
    required: true,
  },
  phone: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  address: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  photo: { type: String },
});

module.exports = mongoose.model('YardOwner', YardOwnerSchema);
